package t4a2;

import java.util.Scanner;

public class T4A2 {


    public static void main(String[] args) {
        //ejercicio1();
        //ejercicio2();
        //jercicio3();
        //ejercicio4();
    }
     public static void ejercicio1() {
    //1.Dise�a una aplicaci�n que muestre las tablas de multiplicar del 1 al 10.
    Scanner scanner = new Scanner(System.in);
    
    System.out.print("Este programa ejecuta las tabla de multiplicar");
   
     for(int i = 1; i<11; i++) {
         
         System.out.println("Esta es la tabla del " + i);
         
             for (int j = 1; j <11; j++) {
                 System.out.println(i + " x " + j + " = " + (i*j));
         }
           System.out.println("\n");                                      
        }
}
       public static void ejercicio2() {
    //2.Realizar un programa en Java que pida un n�mero x, y nos diga cu�ntos n�meros hay entre 1 y x que son primos.
int inicio, fin, contador = 0;

		Scanner sc = new Scanner(System.in);
                
		System.out.println("Escribe el inicio:");
		inicio = sc.nextInt();
		System.out.println("Escribe el fin:");
		fin = sc.nextInt();
                
		for (int x = inicio; x <= fin; x++) {
			if (esPrimo(x)) {
				contador++;
				System.out.print(String.valueOf(x) + ",");
			}
		}
		System.out.printf("\nTotal: %d \n", contador);
		sc.close();
	}

	public static boolean esPrimo(int numero) {
		
		if (numero == 0 || numero == 1 || numero == 4) {
			return false;
		}
		for (int x = 2; x < numero / 2; x++) {

			if (numero % x == 0)
				return false;
		}
		
		return true;
	}

         public static void ejercicio3() {
    //3.Realizar un programa en Java que pida un n�mero x, y nos diga cu�ntos n�meros hay entre 1 y x, cu�ntos pares y cu�ntos impares. 
      Scanner scanner = new Scanner(System.in);
      
    int cant, num, pares=0, impares=0;
    System.out.print("Cuantos numeros desea ingresar: ");
    cant = scanner.nextInt();
    
    for(int i=1; i<=cant; i++){
     System.out.print("Ingresar numero " + i + " de " + cant + ": ");
      num = (new Scanner(System.in)).nextInt();
      
       if(num%2 == 0)
         pares++;
       else
         impares++; }
         
    System.out.println("\nCantidad de numeros pares: " + pares);
    System.out.println("Cantidad de numeros impares: " + impares); 
         } 


           public static void ejercicio4() {
    //4.Un programa en Java que te permita ingresar una palabra y la imprima al rev�s.
    
    Scanner tec = new Scanner (System.in);
    String palabra;
    String invert = " ";
    
    System.out.print("Ingrese una palabra: ");
    palabra =  tec.nextLine();
    
    for (int contador = palabra.length()-1; contador >=0; contador--) {
        invert = invert + palabra.charAt (contador);
        
    }
    System.out.println(invert);
    
           }
           
}
